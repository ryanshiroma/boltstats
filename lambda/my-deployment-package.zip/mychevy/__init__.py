# -*- coding: utf-8 -*-

"""Top-level package for mychevy."""

__author__ = """Sean Dague"""
__email__ = 'sean@dague.net'
__version__ = '2.1.0'
